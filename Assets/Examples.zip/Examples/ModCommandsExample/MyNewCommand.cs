using PugMod;
using QFSW.QC;
using UnityEngine;
using UnityEngine.Scripting;

public class MyNewCommands : MonoBehaviour
{
    [CommandPrefix("modding.")]
    public static class ModdingCommands
    {
        [Preserve]
        [CommandWithModSupport("playPuffVFX", "Plays a visual Puff effect at the players' position.", paramsInGlobalSuggestions: 1)]
        public static void PlayPuffVFX(PuffID puffID, int particleCount = 10)
        {
            if (API.Client.LocalPlayer == null)
            {
                Manager.menu.quantumConsole.LogToConsole("You must be in-game to use this command.");
                return;
            }

            Vector3 playerPosition = API.Client.LocalPlayer.transform.position;
            API.Effects.PlayPuff((int)puffID, playerPosition, particleCount);
            Manager.menu.quantumConsole.LogToConsole($"Played visual effect with ID: {puffID} and particle amount: {particleCount}");
        }
    }
}
