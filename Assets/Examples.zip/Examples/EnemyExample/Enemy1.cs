using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using PugMod;
using UnityEngine;

public class Enemy1 : EntityMonoBehaviour
{
    public GameObject graphics;
    
    protected override void DeathEffect()
    {
        API.Effects.PlayPuff(100, RenderPosition);
        graphics.SetActive(false);    
    }
}