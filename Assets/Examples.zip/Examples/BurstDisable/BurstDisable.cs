using PugMod;
using Unity.Burst;
using Unity.Entities;
using UnityEngine;

public class BurstDisable : IMod
{
	public void EarlyInit()
	{
		// Can't call BurstDisabled here since we are missing some necessary type initialization at this point
	}

	public void Init()
	{
		// Call to disable burst for these specific systems so we can patch them
		BurstDisabler.DisableBurstForSystem<SpawnEnvironmentObjectsInNewAreaSystem>();
		
		// Note: Patches via HarmonyPatchAttribute are applied automatically unless disabled via ModBuilderSettings
	}

	public void Shutdown()
	{
	}

	public void ModObjectLoaded(Object obj)
	{
	}

	public void Update()
	{
	}
}